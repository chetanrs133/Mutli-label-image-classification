		** Dataset for multi-label classification **

			* Specifications *
			
* 10000 images and 6 class labels.
* Files
	+ X.csv		: 32-dim features.
	+ Y.csv 	: Ground truth in k-hot embedding.
	+ labels.csv	: label names.
	+ ImageID.csv	: Image IDs for the dataset.
	+ ImageURLs.txt	: Image URLs corresponding to image IDs. Some(or most) URLs might be dead. 
* The Image URLs are provided for observations and inference purposes only.
